# Product Co-Purchase Network Analysis

**Question:** *(fill in)* What is the overall structure of how products relate to each other across the catalog — which products are central hubs, which bridge otherwise separate shopping patterns, and do products naturally cluster into recognizable groups?

**Key findings:** *(fill in after running; top hub/bridge products, number of communities found, and your recommendation)*

**Tools:** R, `igraph`, `ggraph` (network visualization), tidyverse, Quarto

## Why this project — and how it differs from market-basket-analysis

This portfolio already has a market-basket-analysis project mining individual "if A then B" rules from the same kind of transaction data (the apriori algorithm). This project uses the **same underlying data but a completely different mathematical lens: graph theory.** Instead of scoring individual product pairs, it builds the *entire* co-purchase structure as a network — products as nodes, co-purchases as edges — and studies its overall shape. This answers questions a pairwise rule can't: which products are structurally central? Which ones bridge otherwise disconnected shopping patterns? Do products fall into natural groupings without being told the categories in advance?

## Reproduce

1. Download "Online Retail II" to `data/raw/online_retail_II.xlsx` (see `R/00_get_data.R`) — reuse the file from earlier projects if you already have it
2. `install.packages(c("tidyverse", "janitor", "readxl", "igraph", "ggraph", "scales", "quarto"))`
3. Run in order:
   - `R/01_clean.R`
   - `R/02_build_network.R` (builds the graph, computes centrality, detects communities)
   - Render `reports/report.qmd`

## Method in brief

1. **Build the network**: an edge connects two products whenever they co-occur in the same basket, weighted by how often. Restricted to the top 150 products with a minimum co-purchase count, to avoid an unreadable "hairball" of near-universal connections.
2. **Compute three centrality measures**, each answering a different question: *degree* (how broadly connected is this product?), *betweenness* (how much does this product bridge otherwise separate shopping patterns?), and *eigenvector centrality* (is this product part of the network's well-connected core, not just connected to many low-importance products?).
3. **Detect communities with the Louvain algorithm**, which finds densely-connected product groupings without needing the number of groups specified in advance — unlike k-means clustering, which requires choosing k up front.
4. **Check modularity** to judge whether the detected communities reflect real structure or are closer to noise.
5. **Visualize the whole network** with a force-directed layout, as a sanity check on whether the algorithmic community split "looks right."
6. **Translate structure into action**: hub products for general placement, bridge products for cross-merchandising, communities for bundles or store layout.

## Key concepts

| Concept | Plain-English meaning |
|---|---|
| Node / edge | A product / a co-purchase connection between two products |
| Degree centrality | How many other products this one is commonly bought alongside |
| Betweenness centrality | How often this product sits on the path connecting two otherwise separate parts of the network — a "bridge" |
| Eigenvector centrality | How connected this product is to OTHER well-connected products — part of the network's core, not just broadly connected |
| Network density | Share of all possible product pairs that are actually linked |
| Community detection (Louvain) | Finding groups of nodes more densely connected to each other than to the rest of the network, without specifying the number of groups in advance |
| Modularity | A measure of how meaningful a community split is, compared to a random network of the same size |

## Project structure

```
R/00_get_data.R             data source notes
R/cleaning.R                  cleaning function (basket-product pairs)
R/01_clean.R                   run cleaning
R/network_functions.R           build_product_network(), compute_centrality(), detect_communities() (heavily commented)
R/02_build_network.R             build the graph, compute centrality, detect communities
reports/report.qmd               full write-up: centrality, communities, network visualization, business recommendations
```

## Limitations

*(fill in — see the report's own Limitations section: co-purchase isn't causation, top-150 restriction excludes long-tail products, community detection stability wasn't checked across multiple runs)*
