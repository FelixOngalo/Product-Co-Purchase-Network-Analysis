library(readxl)
library(dplyr)
source("R/cleaning.R")

raw   <- read_excel("data/raw/online_retail_II.xlsx")
clean <- clean_orders(raw)

cat("Basket-product lines:", nrow(clean), "\n")
cat("Unique baskets:      ", n_distinct(clean$invoice_no), "\n")
cat("Unique products:     ", n_distinct(clean$description), "\n")

saveRDS(clean, "data/clean/basket_products_clean.rds")
