library(dplyr)
library(janitor)
library(stringr)

clean_orders <- function(raw) {
  raw |>
    clean_names() |>
    rename(any_of(c(
      invoice_no  = "invoice",
      description = "description",
      stock_code  = "stockcode"
    ))) |>
    mutate(
      description  = str_squish(str_to_upper(description)),
      is_cancelled = grepl("^C", as.character(invoice_no))
    ) |>
    filter(
      !is_cancelled,
      !is.na(description), description != "",
      quantity > 0
    ) |>
    distinct(invoice_no, description)   # one row per (basket, product) -- quantity doesn't matter for network structure
}
