library(dplyr)
library(igraph)
source("R/network_functions.R")

basket_products <- readRDS("data/clean/basket_products_clean.rds")

g <- build_product_network(basket_products, min_co_purchases = 10, top_n_products = 150)

cat("Nodes (products):", vcount(g), "\n")
cat("Edges (co-purchase links):", ecount(g), "\n")
cat("Network density:", round(edge_density(g), 4),
    "(share of all possible product pairs that are actually linked)\n")

centrality <- compute_centrality(g)
cat("\n=== Top 10 products by degree centrality ===\n")
print(head(centrality, 10))

cat("\n=== Top 10 products by betweenness (bridge products) ===\n")
print(centrality |> arrange(desc(betweenness)) |> head(10))

comm_result <- detect_communities(g)
cat("\nCommunities detected:", length(unique(comm_result$membership$community)), "\n")
print(comm_result$membership |> count(community, sort = TRUE))

# Modularity: a measure of how good the community split is -- roughly,
# how much more densely connected products are WITHIN their assigned
# community vs. what you'd expect from a random network of the same
# size. Values above ~0.3 are generally considered a meaningful
# community structure, not just noise.
cat("\nModularity of detected communities:", round(modularity(comm_result$communities), 3), "\n")

results <- centrality |> left_join(comm_result$membership, by = "product")

saveRDS(list(
  graph = g, centrality = results, communities = comm_result$communities,
  modularity = modularity(comm_result$communities)
), "data/clean/network_results.rds")
