# Data: reuse "Online Retail II" (same dataset used across several
# projects in this portfolio) -- transaction-level data, which we'll
# turn into a PRODUCT CO-PURCHASE NETWORK: an edge between two products
# whenever they appear in the same basket together.
#   https://archive.ics.uci.edu/dataset/502/online+retail+ii
# Download the XLSX and place it at data/raw/online_retail_II.xlsx
# (reuse the file from earlier projects if you already have it).
#
# This project uses the SAME underlying data as market-basket-analysis
# but a completely different analytical lens: instead of mining rules
# one pair at a time (apriori), it builds the WHOLE co-purchase
# structure as a graph and studies its shape -- which products are
# central hubs, which cluster into natural "communities," etc.
message("Download Online Retail II to data/raw/online_retail_II.xlsx (reuse from earlier projects if you already have it)")
