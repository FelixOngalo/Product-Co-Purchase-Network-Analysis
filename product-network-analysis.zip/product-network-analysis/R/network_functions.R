# Reusable functions for building and analyzing a product co-purchase
# network with `igraph`. This is graph theory applied to retail data --
# a different mathematical framework than anything else in this
# portfolio (not a regression, not a cluster, not a rule-mining
# algorithm): products become NODES, and an EDGE connects two products
# whenever they appear in the same basket together.

library(dplyr)
library(igraph)

#' Build a weighted product co-purchase network from basket-product
#' data. An edge's weight is how many baskets contained BOTH products.
#'
#' @param basket_products A tibble with one row per (invoice_no, description).
#' @param min_co_purchases Drop edges weaker than this -- without a
#'   floor, the full product catalog produces a dense, unreadable
#'   "hairball" graph where almost every product connects to almost
#'   every other product through at least one shared basket.
#' @param top_n_products Optional: restrict to the N most frequently
#'   purchased products before building edges, to keep the graph a
#'   manageable size for both computation and visualization.
#' @return An igraph graph object with a `weight` edge attribute.
build_product_network <- function(basket_products, min_co_purchases = 10, top_n_products = 150) {
  top_products <- basket_products |>
    count(description, sort = TRUE) |>
    slice_head(n = top_n_products) |>
    pull(description)

  filtered <- basket_products |> filter(description %in% top_products)

  # Self-join baskets against themselves to get every PAIR of products
  # that co-occurred in the same basket -- the core operation that
  # turns "which basket had which products" into "which products
  # co-occur with which other products."
  pairs <- filtered |>
    inner_join(filtered, by = "invoice_no", relationship = "many-to-many") |>
    filter(description.x < description.y) |>   # avoid (A,B) and (B,A) duplicates, and A-A self-pairs
    count(description.x, description.y, name = "weight") |>
    filter(weight >= min_co_purchases)

  graph_from_data_frame(pairs, directed = FALSE)
}

#' Compute three different centrality measures, each answering a
#' different question about "importance" in the network -- using just
#' one measure would give an incomplete (or misleading) picture.
#'
#' @param g An igraph graph object.
#' @return A tibble: product, degree, betweenness, eigenvector centrality.
compute_centrality <- function(g) {
  tibble(
    product = V(g)$name,
    # Degree: how many OTHER products this one is commonly bought with.
    # Answers: "how broadly connected is this product?"
    degree = degree(g),
    # Betweenness: how often this product sits on the shortest path
    # between two OTHER products. Answers: "how much does this product
    # act as a BRIDGE connecting different parts of the shopping
    # pattern?" -- a product can have modest degree but high
    # betweenness if it's the one thing linking two otherwise separate
    # clusters of purchases.
    betweenness = betweenness(g, weights = NA),
    # Eigenvector centrality: how connected this product is to OTHER
    # well-connected products. Answers: "is this product part of the
    # network's core, surrounded by other popular items?" -- distinct
    # from degree, since a product can connect to many low-importance
    # products (high degree) without being central to the network's
    # core (low eigenvector centrality).
    eigenvector = eigen_centrality(g)$vector
  ) |>
    arrange(desc(degree))
}

#' Detect communities (clusters of products that are more densely
#' connected to each other than to the rest of the network) using the
#' Louvain algorithm -- a standard, fast community-detection method
#' that doesn't require specifying the number of communities in
#' advance (unlike k-means, which needs k chosen up front).
#'
#' @param g An igraph graph object.
#' @return A list: the community object, and a tibble mapping each
#'   product to its community ID.
detect_communities <- function(g) {
  comm <- cluster_louvain(g, weights = E(g)$weight)

  membership_tbl <- tibble(
    product   = V(g)$name,
    community = as.integer(membership(comm))
  )

  list(communities = comm, membership = membership_tbl)
}
